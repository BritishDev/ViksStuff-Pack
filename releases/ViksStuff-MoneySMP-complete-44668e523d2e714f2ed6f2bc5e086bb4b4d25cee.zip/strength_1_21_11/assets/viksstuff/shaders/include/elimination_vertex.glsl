uniform sampler2D Sampler0;
// Screen-only Polus presentation. Reserved colors never affect ordinary text.
flat out int polusKind;
flat out float polusPhase;
out vec2 polusUV;
out vec2 polusCanvas;
// Bow mode: all positions remain relative to the same aspect-safe screen canvas.
flat out int polusSlot;
flat out int polusTotal;

void polusBowPosition(inout vec4 position, inout vec4 tint, ivec3 m, vec2 screen, vec2 canvas, vec2 origin) {
    int corner=gl_VertexID&3;
    polusUV=vec2(corner<2?0.0:1.0,(corner==0||corner==3)?0.0:1.0);
    polusPhase=float(m.g);
    polusSlot=0;polusTotal=1;
    bool victim=m.r==40&&m.b==44;
    bool head=m.r==40&&m.b==45;
    bool arrow=m.r==42&&m.b==46;
    bool bow=m.r==42&&m.b==47;
    polusKind=victim?7:(head?9:(arrow?11:(bow?10:8)));
    vec2 center=vec2(.23,.54);vec2 size=vec2(.30*.75*9.0/16.0,.30);
    if(polusKind==8){
        polusSlot=m.b-64;polusTotal=m.r-63;
        if(polusSlot==0){center=vec2(.61,.54);size=vec2(.30*.75*9.0/16.0,.30);}
        else{
            float count=float(max(1,polusTotal-1));
            float columns=min(count,ceil(sqrt(count*1.5)));
            float rows=ceil(count/columns);
            float height=min(.23,min(.33/rows,.24/columns*32.0/9.0));
            float slot=float(polusSlot-1);
            center=vec2(.73+(mod(slot,columns)+.5)*.24/columns,.68-.025*(rows-1.0-floor(slot/columns))-height*.5);
            size=vec2(height*.75*9.0/16.0,height);
        }
    }
    if(polusKind==7||polusKind==8){
        center.y+=sin(polusPhase*.13+float(polusSlot)*1.7)*.0015;
        position.xy=origin+(center+(polusUV-.5)*size)*canvas;
    }else if(head){
        float t=clamp((polusPhase-48.0)/24.0,0.0,1.0);
        center=vec2(.23+.30*t,.4275-.12*t+1.15*t*t);
        float angle=3.6*t;
        vec2 local=(polusUV-.5)*.075;
        local=mat2(cos(angle),sin(angle),-sin(angle),cos(angle))*local;
        position.xy=origin+(center+local*vec2(9.0/16.0,1.0))*canvas;
    }else if(bow){
        position.xy=origin+(vec2(.553,.535-.045*smoothstep(8.0,24.0,polusPhase)*(1.0-smoothstep(40.0,54.0,polusPhase)))+(polusUV-.5)*vec2(.075*9.0/16.0,.075))*canvas;
    }else{
        float t=clamp((polusPhase-36.0)/12.0,0.0,1.0);
        center=mix(vec2(.55,.49),vec2(.23,.4275),t);
        vec2 local=(polusUV-.5)*vec2(.06*16.0/9.0,.014);
        float angle=.10943;
        local=mat2(cos(angle),sin(angle),-sin(angle),cos(angle))*local;
        position.xy=origin+(center+local*vec2(9.0/16.0,1.0))*canvas;
    }
    polusCanvas=(position.xy-origin)/canvas;
    position.z=(-.81-ProjMat[3][2])/ProjMat[2][2];
    tint=vec4(1.0,1.0,1.0,Color.a);
}

void polusScene(inout vec4 position, inout vec4 tint) {
    polusSlot=0;polusTotal=1;polusKind=0;polusPhase=0.0;polusUV=vec2(0.0);polusCanvas=vec2(0.0);
    ivec3 m=ivec3(round(Color.rgb*255.0));
    if(abs(ProjMat[3][3]-1.0)>0.001)return;
    // Crowds only use sanitized native skin textures, a bounded timeline and
    // their reserved control range; ordinary white head icons stay untouched.
    bool skinAtlas=all(equal(textureSize(Sampler0,0),ivec2(64)));
    bool actor=skinAtlas&&m.g<72&&((m.r==40&&(m.b==44||m.b==45))||(m.r>=64&&m.b>=64&&m.b-64<m.r-63));
    bool weapon=m.r==42&&m.g<72&&(m.b==46||m.b==47);
    if(actor||weapon){
        vec2 screen=vec2(2.0/ProjMat[0][0],-2.0/ProjMat[1][1]);
        vec2 canvas=vec2(min(screen.x,screen.y*16.0/9.0),min(screen.y,screen.x*9.0/16.0));
        polusBowPosition(position,tint,m,screen,canvas,(screen-canvas)*.5);return;
    }
    bool black=m.b==41&&m.r==9;
    bool red=m.b==41&&m.r==8;
    bool wall=m.b==41&&m.r>=10&&m.r<28;
    bool body=m.b==42&&m.r==30;
    bool lava=m.b==43&&m.r==31;
    // The signature belongs only to the private elimination font atlas.
    // Normal GUI/chat/scoreboard reds must never become screen coordinates.
    bool text=(m.r==6||m.r==7)&&m.b>=128&&m.b<=159;
    if(text)text=all(equal(ivec3(round(texture(Sampler0,UV0).rgb*255.0)),ivec3(251,249,247)));
    if(!red&&!black&&!wall&&!body&&!lava&&!text)return;
    vec2 screen=vec2(2.0/ProjMat[0][0],-2.0/ProjMat[1][1]);
    vec2 canvas=vec2(min(screen.x,screen.y*16.0/9.0),min(screen.y,screen.x*9.0/16.0));
    vec2 origin=(screen-canvas)*0.5;
    polusKind=red?6:(black?5:(wall?1:(body?2:(lava?3:4))));polusPhase=float(m.g);
    int corner=gl_VertexID&3;
    polusUV=vec2(corner<2?0.0:1.0,(corner==0||corner==3)?0.0:1.0);
    if(black){position.xy=polusUV*screen;polusCanvas=(position.xy-origin)/canvas;}else if(text){
        // Glyph width and horizontal advance are encoded per letter. No subtitle
        // coordinates or native title matrix scale participate in this layout.
        polusPhase=float(((m.b-128)%16)/2+(m.b>=144?16:0));
        int glyphCode=(m.b&1)*256+m.g;
        float advance=float(glyphCode)-256.0;
        float glyphWidth=8.0; // The native bitmap uploads the entire 8px cell, not its ink width.
        float scale=canvas.x/1280.0*3.4;
        position.xy=origin+canvas*vec2(.5,.47)+vec2(advance+polusUV.x*glyphWidth,(polusUV.y-.5)*8.0)*scale;
        // A separate glyph pass keeps the shadow inside the same layout and fade.
        if(m.r==7){position.xy+=vec2(scale);polusPhase+=32.0;}
        polusCanvas=(position.xy-origin)/canvas;
    }else if(wall){
        int index=m.r-10;int tile=index%6;int repeat=index/6;
        float pan=smoothstep(0.0,14.0,float(m.g));
        vec2 p=vec2(float(repeat)*.43+float(tile%2)*.215,
            -.285*pan+float(tile/2)*(1.051/2.75));
        polusCanvas=p+polusUV*vec2(.215,1.051/2.75);
        position.xy=origin+polusCanvas*canvas;
    }else if(body){
        float t=clamp(float(m.g)/18.0,0.0,1.0);
        vec2 center=vec2(.28+.28*t,.16-.20*t+1.15*t*t);
        float angle=-.35+3.6*t;
        vec2 local=(polusUV-.5)*.135;
        vec2 spun=mat2(cos(angle),sin(angle),-sin(angle),cos(angle))*local;
        polusCanvas=center+spun*vec2(9.0/16.0,1.0);
        position.xy=origin+polusCanvas*canvas;
    }else{
        polusCanvas=polusUV;position.xy=origin+polusUV*canvas;
    }
    // Preserve intended depth for see-through pipelines; GUI_TEXT ignores depth.
    float depth=red?-.69:(black?-.68:(wall?-.70:(body?-.74:(lava?-.76:-.80))));
    position.z=(depth-ProjMat[3][2])/ProjMat[2][2];
    tint=vec4(1.0,1.0,1.0,Color.a);
}
