flat in int polusKind;
flat in float polusPhase;
in vec2 polusUV;
in vec2 polusCanvas;
vec4 polusSkin(ivec2 base,ivec2 overlay){
    ivec2 size=textureSize(Sampler0,0);
    vec4 b=texelFetch(Sampler0,base*size/64,0);
    vec4 o=texelFetch(Sampler0,overlay*size/64,0);
    return vec4(mix(b.rgb,o.rgb,o.a),max(b.a,o.a));
}
// GUI_TEXT uses NO_DEPTH_TEST. The background must leave the opaque head
// footprint clear even when Minecraft sorts its skin texture before cave pages.
bool polusHeadFootprint(){
    if(polusPhase<20.0||polusPhase>=40.0||polusCanvas.y>.675)return false;
    float t=clamp((polusPhase-20.0)/18.0,0.0,1.0);
    vec2 center=vec2(.28+.28*t,.16-.20*t+1.15*t*t);
    float angle=-.35+3.6*t;
    vec2 p=(polusCanvas-center)*vec2(16.0/9.0,1.0);
    vec2 local=mat2(cos(angle),-sin(angle),sin(angle),cos(angle))*p;
    return all(lessThanEqual(abs(local),vec2(.06752)));
}
flat in int polusSlot;
flat in int polusTotal;

bool polusRect(vec2 p,vec2 start,vec2 size){return all(greaterThanEqual(p,start))&&all(lessThan(p,start+size));}
vec4 polusLimb(vec2 p,vec2 base,vec2 overlay){
    return polusSkin(ivec2(base+floor(p)),ivec2(overlay+floor(p)));
}
vec2 polusRotate(vec2 p,float angle){return mat2(cos(angle),-sin(angle),sin(angle),cos(angle))*p;}
vec4 polusActor(){
    vec2 p=polusUV*vec2(24.0,32.0)-vec2(4.0,0.0);
    // Tiny idle shoulder motion; the archer lifts the bow arm before release.
    float lift=polusKind==8&&polusSlot==0?smoothstep(8.0,24.0,polusPhase)*(1.0-smoothstep(40.0,54.0,polusPhase)):0.0;
    vec2 left=polusRotate(p-vec2(4.0,9.0),lift*1.2)+vec2(4.0,9.0);
    vec2 right=polusRotate(p-vec2(12.0,9.0),lift*.65)+vec2(12.0,9.0);
    vec4 c=vec4(0.0);
    if(polusRect(left,vec2(0.0,8.0),vec2(4.0,12.0)))c=polusLimb(left-vec2(0.0,8.0),vec2(44.0,20.0),vec2(44.0,36.0));
    if(polusRect(right,vec2(12.0,8.0),vec2(4.0,12.0)))c=polusLimb(right-vec2(12.0,8.0),vec2(36.0,52.0),vec2(52.0,52.0));
    if(polusRect(p,vec2(4.0,8.0),vec2(8.0,12.0)))c=polusLimb(p-vec2(4.0,8.0),vec2(20.0,20.0),vec2(20.0,36.0));
    if(polusRect(p,vec2(4.0,20.0),vec2(4.0,12.0)))c=polusLimb(p-vec2(4.0,20.0),vec2(4.0,20.0),vec2(4.0,36.0));
    if(polusRect(p,vec2(8.0,20.0),vec2(4.0,12.0)))c=polusLimb(p-vec2(8.0,20.0),vec2(20.0,52.0),vec2(4.0,52.0));
    if(polusRect(p,vec2(4.0,0.0),vec2(8.0,8.0)))c=polusLimb(p-vec2(4.0,0.0),vec2(8.0,8.0),vec2(40.0,8.0));
    return c*vec4(1.0,1.0,1.0,vertexColor.a);
}
vec4 polusBowColor(){
    if(any(lessThan(polusCanvas,vec2(0.0)))||any(greaterThan(polusCanvas,vec2(1.0))))discard;
    if(polusKind==7||polusKind==8)return polusActor();
    if(polusKind==9){
        // The head disappears beneath the lava instead of drawing over it.
        if(polusCanvas.y>.783)discard;
        ivec2 p=clamp(ivec2(floor(polusUV*8.0)),ivec2(0),ivec2(7));
        return polusSkin(ivec2(8+p.x,8+p.y),ivec2(40+p.x,8+p.y))*vec4(1.0,1.0,1.0,vertexColor.a);
    }
    if(polusKind==10)return texture(Sampler0,texCoord0)*vec4(1.0,1.0,1.0,vertexColor.a);
    // Left-pointing arrow with a grey tip, wooden shaft and white fletching.
    vec2 p=polusUV;
    if(p.x<.22&&abs(p.y-.5)<(.22-p.x)*1.8)return vec4(.78,.8,.83,vertexColor.a);
    if(p.x>=.15&&p.x<.94&&abs(p.y-.5)<.09)return vec4(.60,.40,.20,vertexColor.a);
    if(p.x>.72&&p.x<.95&&abs(p.y-.5)<.3)return vec4(.95,.95,.90,vertexColor.a);
    discard;
}

vec4 polusColor(){
    if(polusKind>=7)return polusBowColor();
    if((polusKind==1||polusKind==3||polusKind==5||polusKind==6)&&polusHeadFootprint())discard;
    if(polusKind==5)return vec4(0.0,0.0,0.0,vertexColor.a);
    if(any(lessThan(polusCanvas,vec2(0.0)))||any(greaterThan(polusCanvas,vec2(1.0))))discard;
    if(polusKind==6)return vec4(1.0,64.0/255.0,20.0/255.0,vertexColor.a);
    if(polusKind==1)return texture(Sampler0,texCoord0)*vertexColor*ColorModulator;
    if(polusKind==4){
        bool shadow=polusPhase>=32.0;
        float phase=mod(polusPhase,32.0);
        vec3 ink=shadow?vec3(0.0):(phase>=16.0?vec3(1.0,0.20,0.20):vec3(1.0));
        float alpha=texture(Sampler0,texCoord0).a*(1.0-mod(phase,16.0)/8.0);
        return vec4(ink,alpha*(shadow?0.75:1.0))*vertexColor*ColorModulator;
    }
    if(polusKind==2){
        if(polusCanvas.y>.675)discard;
        ivec2 p=clamp(ivec2(floor(polusUV*8.0)),ivec2(0),ivec2(7));
        vec4 c=polusSkin(ivec2(8+p.x,8+p.y),ivec2(40+p.x,8+p.y));
        return c*vec4(1.0,1.0,1.0,vertexColor.a);
    }
    // Three original lava bands: the red shoreline belongs to the cave art.
    float phase=polusPhase*6.28318530718/256.0;
    float orange=.783+.006*sin(polusCanvas.x*44.0+phase*4.0)+.003*sin(polusCanvas.x*85.0-phase*8.0);
    float yellow=.920+.005*sin(polusCanvas.x*30.0-phase*4.0);
    if(polusCanvas.y<orange)discard;
    vec3 color=polusCanvas.y<yellow?vec3(1.0,127.0/255.0,0.0):vec3(254.0/255.0,199.0/255.0,34.0/255.0);
    return vec4(color,vertexColor.a);
}

