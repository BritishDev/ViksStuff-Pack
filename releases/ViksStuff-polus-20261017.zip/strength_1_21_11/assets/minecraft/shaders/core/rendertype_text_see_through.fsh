#version 330

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

#moj_import <viksstuff:elimination_fragment.glsl>

#moj_import <viksstuff:elimination_fragment.glsl>

void main() {
    if(polusKind>0){vec4 color=polusColor();if(color.a<.1)discard;fragColor=color;return;}
    if(polusKind>0){vec4 color=polusColor();if(color.a<.1)discard;fragColor=color;return;}
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = color * ColorModulator;
}
