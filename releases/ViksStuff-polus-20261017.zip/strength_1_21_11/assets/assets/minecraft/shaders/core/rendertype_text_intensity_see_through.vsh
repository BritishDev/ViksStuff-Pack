#version 330

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;

out vec4 vertexColor;
out vec2 texCoord0;

#moj_import <viksstuff:parkour_hud.glsl>

#moj_import <viksstuff:elimination_vertex.glsl>

void main() {
    vec4 position = ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    parkourHud(position, vertexColor);
    polusScene(position, vertexColor);
    gl_Position = ProjMat * position;
    texCoord0 = UV0;
}
