// Screen-only Polus presentation. Reserved colors never affect ordinary text.
flat out int polusKind;
flat out float polusPhase;
out vec2 polusUV;
out vec2 polusCanvas;
void polusScene(inout vec4 position, inout vec4 tint) {
    polusKind=0;polusPhase=0.0;polusUV=vec2(0.0);polusCanvas=vec2(0.0);
    ivec3 m=ivec3(round(Color.rgb*255.0));
    if(abs(ProjMat[3][3]-1.0)>0.001)return;
    bool black=m.b==41&&m.r==9;
    bool red=m.b==41&&m.r==8;
    bool wall=m.b==41&&m.r>=10&&m.r<28;
    bool body=m.b==42&&m.r==30;
    bool lava=m.b==43&&m.r==31;
    bool text=m.b==44&&m.r==32;
    if(!red&&!black&&!wall&&!body&&!lava&&!text)return;
    vec2 screen=vec2(2.0/ProjMat[0][0],-2.0/ProjMat[1][1]);
    vec2 canvas=vec2(min(screen.x,screen.y*16.0/9.0),min(screen.y,screen.x*9.0/16.0));
    vec2 origin=(screen-canvas)*0.5;
    polusKind=red?6:(black?5:(wall?1:(body?2:(lava?3:4))));polusPhase=float(m.g);
    int corner=gl_VertexID&3;
    polusUV=vec2(corner<2?0.0:1.0,(corner==0||corner==3)?0.0:1.0);
    if(black){polusCanvas=polusUV;position.xy=polusUV*screen;}else if(text){
        // Native subtitle centering + invisible suffix fixes the typing anchor.
        position.x=screen.x*.5+(position.x-screen.x*.5)*canvas.x/1280.0;
        position.y=origin.y+canvas.y*.5+(position.y-(screen.y*.5+10.0))*canvas.x/1280.0;
        polusCanvas=(position.xy-origin)/canvas;
    }else if(wall){
        int index=m.r-10;int tile=index%6;int repeat=index/6;
        float pan=smoothstep(0.0,48.0,float(m.g));
        vec2 p=vec2(float(repeat)*.43+float(tile%2)*.215,
            -.285*pan+float(tile/2)*(1.051/2.75));
        polusCanvas=p+polusUV*vec2(.215,1.051/2.75);
        position.xy=origin+polusCanvas*canvas;
    }else if(body){
        float t=clamp((float(m.g)-18.0)/64.0,0.0,1.0);
        float top=.19+1.15*t*t;
        polusCanvas=vec2(.5-.0646875*.5,top)+polusUV*vec2(.0646875,.23);
        position.xy=origin+polusCanvas*canvas;
    }else{
        polusCanvas=polusUV;position.xy=origin+polusUV*canvas;
    }
    // Stable depth order, independent of native text texture batching.
    float depth=red?-.69:(black?-.68:(wall?-.70:(body?-.74:(lava?-.76:-.80))));
    position.z=(depth-ProjMat[3][2])/ProjMat[2][2];
    tint=vec4(1.0,1.0,1.0,Color.a);
}
