flat in int polusKind;
flat in float polusPhase;
in vec2 polusUV;
in vec2 polusCanvas;
vec4 polusSkin(ivec2 base,ivec2 overlay){
    ivec2 size=textureSize(Sampler0,0);
    vec4 b=texelFetch(Sampler0,base*size/64,0);
    vec4 o=texelFetch(Sampler0,overlay*size/64,0);
    return vec4(mix(b.rgb,o.rgb,o.a),max(b.a,o.a));
}
vec4 polusColor(){
    if(polusKind==5)return vec4(0.0,0.0,0.0,vertexColor.a);
    if(any(lessThan(polusCanvas,vec2(0.0)))||any(greaterThan(polusCanvas,vec2(1.0))))discard;
    if(polusKind==6)return vec4(1.0,64.0/255.0,20.0/255.0,vertexColor.a);
    if(polusKind==1||polusKind==4)return texture(Sampler0,texCoord0)*vertexColor*ColorModulator;
    if(polusKind==2){
        if(polusCanvas.y>.675)discard;
        ivec2 p=ivec2(floor(polusUV*vec2(16.0,32.0)));vec4 c=vec4(0.0);
        if(p.y<8&&p.x>=4&&p.x<12)c=polusSkin(ivec2(8+p.x-4,8+p.y),ivec2(40+p.x-4,8+p.y));
        else if(p.y>=8&&p.y<20){
            if(p.x>=4&&p.x<12)c=polusSkin(ivec2(20+p.x-4,20+p.y-8),ivec2(20+p.x-4,36+p.y-8));
            else if(p.x<4)c=polusSkin(ivec2(44+p.x,20+p.y-8),ivec2(44+p.x,36+p.y-8));
            else c=polusSkin(ivec2(36+p.x-12,52+p.y-8),ivec2(52+p.x-12,52+p.y-8));
        }else if(p.y>=20&&p.y<32){
            if(p.x>=4&&p.x<8)c=polusSkin(ivec2(4+p.x-4,20+p.y-20),ivec2(4+p.x-4,36+p.y-20));
            else if(p.x>=8&&p.x<12)c=polusSkin(ivec2(20+p.x-8,52+p.y-20),ivec2(4+p.x-8,52+p.y-20));
        }
        return c*vec4(1.0,1.0,1.0,vertexColor.a);
    }
    // Three original lava bands: the red shoreline belongs to the cave art.
    float phase=polusPhase*6.28318530718/256.0;
    float orange=.783+.006*sin(polusCanvas.x*44.0+phase*4.0)+.003*sin(polusCanvas.x*85.0-phase*8.0);
    float yellow=.920+.005*sin(polusCanvas.x*30.0-phase*4.0);
    if(polusCanvas.y<orange)discard;
    vec3 color=polusCanvas.y<yellow?vec3(1.0,127.0/255.0,0.0):vec3(254.0/255.0,199.0/255.0,34.0/255.0);
    return vec4(color,vertexColor.a);
}
