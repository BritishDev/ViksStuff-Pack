flat in int polusKind;
flat in float polusPhase;
in vec2 polusUV;
in vec2 polusCanvas;
vec4 polusSkin(ivec2 base,ivec2 overlay){
    ivec2 size=textureSize(Sampler0,0);
    vec4 b=texelFetch(Sampler0,base*size/64,0);
    vec4 o=texelFetch(Sampler0,overlay*size/64,0);
    return vec4(mix(b.rgb,o.rgb,o.a),max(b.a,o.a));
}
vec4 polusColor(){
    if(polusKind==5)return vec4(0.0,0.0,0.0,vertexColor.a);
    if(any(lessThan(polusCanvas,vec2(0.0)))||any(greaterThan(polusCanvas,vec2(1.0))))discard;
    if(polusKind==6)return vec4(1.0,64.0/255.0,20.0/255.0,vertexColor.a);
    if(polusKind==1)return texture(Sampler0,texCoord0)*vertexColor*ColorModulator;
    if(polusKind==4)return texture(Sampler0,texCoord0)*vec4(1.0,0.20,0.20,1.0-polusPhase/8.0)*vertexColor*ColorModulator;
    if(polusKind==2){
        if(polusCanvas.y>.675)discard;
        ivec2 p=clamp(ivec2(floor(polusUV*8.0)),ivec2(0),ivec2(7));
        vec4 c=polusSkin(ivec2(8+p.x,8+p.y),ivec2(40+p.x,8+p.y));
        return c*vec4(1.0,1.0,1.0,vertexColor.a);
    }
    // Three original lava bands: the red shoreline belongs to the cave art.
    float phase=polusPhase*6.28318530718/256.0;
    float orange=.783+.006*sin(polusCanvas.x*44.0+phase*4.0)+.003*sin(polusCanvas.x*85.0-phase*8.0);
    float yellow=.920+.005*sin(polusCanvas.x*30.0-phase*4.0);
    if(polusCanvas.y<orange)discard;
    vec3 color=polusCanvas.y<yellow?vec3(1.0,127.0/255.0,0.0):vec3(254.0/255.0,199.0/255.0,34.0/255.0);
    return vec4(color,vertexColor.a);
}
